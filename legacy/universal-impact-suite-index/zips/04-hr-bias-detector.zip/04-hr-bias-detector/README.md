# hr-bias-detector

Proyecto independiente 4/50 del Universal Impact Suite.

## Estado
Scaffold profesional inicial; la implementación funcional y sus validaciones se desarrollarán por fases.
